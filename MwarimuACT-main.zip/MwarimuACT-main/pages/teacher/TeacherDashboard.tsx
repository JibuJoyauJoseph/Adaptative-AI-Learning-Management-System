
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import apiClient from '../../api/client';
import { Quiz } from '../../types';

const TeacherDashboard: React.FC = () => {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'active' | 'progress'>('overview');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data } = await apiClient.get('/teacher/quizzes');
        setQuizzes(data);
      } catch (err) {
        console.error('Failed to fetch teacher quizzes');
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  const StatusPill = ({ status }: { status: string }) => {
    switch (status) {
      case 'LIVE': return <span className="flex items-center space-x-1.5 px-3 py-1 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-full text-[10px] font-black uppercase tracking-widest"><span className="w-1.5 h-1.5 rounded-full bg-indigo-600 animate-pulse"></span><span>Live</span></span>;
      case 'COMPLETED': return <span className="flex items-center space-x-1.5 px-3 py-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-full text-[10px] font-black uppercase tracking-widest"><span>✓</span><span>Completed</span></span>;
      case 'IN_PROGRESS': return <span className="flex items-center space-x-1.5 px-3 py-1 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 rounded-full text-[10px] font-black uppercase tracking-widest"><span>⟳</span><span>In Progress</span></span>;
      default: return null;
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
           <div className="flex items-center space-x-3 text-sm font-bold text-slate-400 dark:text-slate-500 mb-2">
              <span>Reports</span>
              <span>/</span>
              <span className="text-slate-900 dark:text-slate-100">Quiz</span>
           </div>
           <h1 className="text-3xl font-black text-slate-900 dark:text-slate-100 uppercase tracking-tight">Quiz Reports</h1>
        </div>
        <div className="flex items-center space-x-4">
           <button className="px-6 py-3 bg-slate-900 dark:bg-indigo-600 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-indigo-600 transition-all shadow-xl shadow-slate-200 dark:shadow-none">Export Report</button>
           <Link to="/create-quiz" className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-all">⚙️</Link>
        </div>
      </div>

      <div className="flex items-center space-x-8 border-b border-slate-100 dark:border-slate-800 pb-2">
        {['Overview', 'Active', 'Progress'].map((tab) => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab.toLowerCase() as any)}
            className={`pb-4 text-sm font-black uppercase tracking-widest transition-all relative ${activeTab === tab.toLowerCase() ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300'}`}
          >
            {tab}
            {activeTab === tab.toLowerCase() && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 dark:bg-indigo-400 rounded-full"></div>}
          </button>
        ))}
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden min-h-[400px]">
        <div className="p-8 border-b border-slate-50 dark:border-slate-800 flex flex-wrap justify-between items-center gap-6">
           <div className="flex items-center space-x-4">
              <h3 className="font-black text-slate-800 dark:text-slate-100 text-sm uppercase tracking-widest">All Quizzes <span className="text-slate-400 dark:text-slate-500 font-bold ml-1">({quizzes.length})</span></h3>
              <button className="flex items-center space-x-2 px-4 py-2 bg-slate-50 dark:bg-slate-800 text-[10px] font-black uppercase text-slate-500 dark:text-slate-400 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700">
                <span>⚡ Add Filter</span>
              </button>
           </div>
           <div className="flex items-center space-x-4 w-full md:w-auto">
              <div className="relative flex-1 md:flex-none md:w-64">
                <input placeholder="Search Quiz..." className="w-full bg-slate-50 dark:bg-slate-800 px-6 py-2.5 rounded-xl border-none text-sm font-medium focus:ring-2 focus:ring-indigo-100 dark:focus:ring-indigo-900/50 outline-none text-slate-800 dark:text-slate-100" />
              </div>
              <button className="px-5 py-2.5 bg-indigo-600 text-white font-black text-[10px] uppercase rounded-xl">Export</button>
           </div>
        </div>

        {isLoading ? (
          <div className="p-20 text-center animate-pulse">
            <p className="text-slate-400 dark:text-slate-500 font-black uppercase tracking-widest">Loading assessment data...</p>
          </div>
        ) : quizzes.length === 0 ? (
          <div className="p-20 text-center">
             <div className="text-5xl mb-6 grayscale opacity-20">📊</div>
             <p className="text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">No quiz data available for this account</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left min-w-[1000px]">
              <thead className="bg-slate-50/50 dark:bg-slate-800/50 text-[10px] font-black uppercase text-slate-400 dark:text-slate-500 tracking-widest border-b border-slate-50 dark:border-slate-800">
                <tr>
                  <th className="px-8 py-6 flex items-center space-x-2">
                    <input type="checkbox" className="rounded dark:bg-slate-800 dark:border-slate-700" />
                    <span>Quiz Name</span>
                  </th>
                  <th className="px-8 py-6">Status</th>
                  <th className="px-8 py-6">Learners</th>
                  <th className="px-8 py-6">Accuracy</th>
                  <th className="px-8 py-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                {quizzes.map((quiz) => (
                  <tr key={quiz.id} className="hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors group cursor-pointer">
                    <td className="px-8 py-6">
                      <div className="flex items-center space-x-4">
                        <input type="checkbox" className="rounded dark:bg-slate-800 dark:border-slate-700" />
                        <div>
                          <p className="text-sm font-black text-slate-800 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{quiz.title}</p>
                          <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mt-1 tracking-tight">{quiz.description}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <StatusPill status={quiz.status || 'LIVE'} />
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex -space-x-2">
                        {[1, 2, 3].map(idx => (
                          <div key={idx} className="w-8 h-8 rounded-full border-2 border-white dark:border-slate-900 bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-[10px] text-slate-400">
                            👤
                          </div>
                        ))}
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center space-x-3">
                         <div className="flex-1 w-20 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-500 rounded-full" style={{ width: '75%' }}></div>
                         </div>
                         <span className="text-xs font-black text-slate-800 dark:text-slate-100">75%</span>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                       <button className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest hover:text-indigo-600 dark:hover:text-indigo-400">Manage</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeacherDashboard;
