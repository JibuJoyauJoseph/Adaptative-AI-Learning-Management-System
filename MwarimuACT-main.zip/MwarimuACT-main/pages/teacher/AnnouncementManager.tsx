
import React, { useState, useEffect } from 'react';
import apiClient from '../../api/client';
import { Announcement, UserRole, Class } from '../../types';
import { useAuth } from '../../context/AuthContext';

const AnnouncementManager: React.FC = () => {
  const { user } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [classes, setClasses] = useState<Class[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    classId: 'all'
  });

  const fetchData = async () => {
    try {
      const [annRes, classRes] = await Promise.all([
        apiClient.get('/announcements'),
        apiClient.get('/admin/classes').catch(() => ({ data: [
          { id: 'c1', name: 'CS101: Web Dev', teacherId: 't1' },
          { id: 'c2', name: 'PH102: Physics', teacherId: 't2' }
        ] }))
      ]);
      setAnnouncements(annRes.data);
      setClasses(classRes.data);
    } catch (err) {
      // Fallback for demo
      setAnnouncements([
        { id: '1', title: 'Welcome to Term 2', content: 'Classes begin next Monday. Please check your schedule.', createdAt: new Date().toISOString(), authorId: 't1' },
        { id: '2', title: 'Library Renovation', content: 'The main library will be closed for maintenance this weekend.', createdAt: new Date().toISOString(), authorId: 'adm1' }
      ]);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await apiClient.post('/announcements', formData);
      setShowForm(false);
      setFormData({ title: '', content: '', classId: 'all' });
      fetchData();
    } catch (err) {
      alert('Announcement deployed (Demo Mode)');
      setShowForm(false);
      setFormData({ title: '', content: '', classId: 'all' });
    } finally {
      setLoading(false);
    }
  };

  const handleRetract = async (id: string) => {
    if (window.confirm('Are you sure you want to retract this announcement?')) {
      try {
        await apiClient.delete(`/announcements/${id}`);
        fetchData();
      } catch (err) {
        setAnnouncements(prev => prev.filter(a => a.id !== id));
      }
    }
  };

  const isAdmin = user?.role === UserRole.ADMIN;

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Broadcasting Hub</h1>
          <p className="text-slate-500 font-medium">
            {isAdmin 
              ? 'Institutional control for global alerts and system-wide messaging.' 
              : 'Communicate updates to your assigned classes.'}
          </p>
        </div>
        <button 
          onClick={() => setShowForm(true)} 
          className="px-8 py-4 bg-blue-600 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-blue-700 shadow-2xl shadow-blue-200 transition-all"
        >
          Draft Announcement
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {showForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 backdrop-blur-md bg-slate-900/40 animate-in fade-in duration-300">
            <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95">
              <form onSubmit={handleSubmit} className="p-10 lg:p-14 space-y-8">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">New Broadcast</h2>
                  <button type="button" onClick={() => setShowForm(false)} className="text-slate-300 hover:text-slate-900 transition-colors text-2xl">✕</button>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2 block">Subject Line</label>
                    <input 
                      required
                      value={formData.title}
                      onChange={e => setFormData({...formData, title: e.target.value})}
                      className="w-full bg-slate-50 border-2 border-slate-50 px-6 py-4 rounded-2xl focus:border-blue-500 focus:bg-white outline-none transition-all font-bold text-slate-800" 
                      placeholder="Enter a descriptive title..." 
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2 block">Target Segment</label>
                    <select 
                      value={formData.classId}
                      onChange={e => setFormData({...formData, classId: e.target.value})}
                      className="w-full bg-slate-50 border-2 border-slate-50 px-6 py-4 rounded-2xl focus:border-blue-500 focus:bg-white outline-none transition-all font-black text-xs uppercase tracking-widest"
                    >
                      <option value="all">Global (Everyone)</option>
                      {isAdmin && <option value="faculty">Faculty & Staff Only</option>}
                      <optgroup label="Specific Academic Units">
                        {classes.map(c => (
                          <option key={c.id} value={c.id}>{c.name}</option>
                        ))}
                      </optgroup>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2 block">Message Body</label>
                    <textarea 
                      required
                      value={formData.content}
                      onChange={e => setFormData({...formData, content: e.target.value})}
                      className="w-full bg-slate-50 border-2 border-slate-50 px-6 py-4 rounded-2xl focus:border-blue-500 focus:bg-white outline-none transition-all font-medium text-slate-600 h-48 resize-none" 
                      placeholder="Compose your message..." 
                    />
                  </div>
                </div>

                <div className="pt-4 flex flex-col gap-4">
                  <button 
                    type="submit" 
                    disabled={loading}
                    className="w-full py-5 bg-slate-900 text-white font-black text-xs uppercase tracking-[0.2em] rounded-[1.5rem] hover:bg-blue-600 shadow-2xl transition-all disabled:opacity-50"
                  >
                    {loading ? 'Transmitting...' : 'Release Broadcast'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="lg:col-span-3 space-y-6">
          <h3 className="text-sm font-black text-slate-400 uppercase tracking-[0.2em]">Transmission History</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {announcements.map(ann => {
              const isAuthor = ann.authorId === user?.id;
              const canRetract = isAdmin || isAuthor;
              
              return (
                <div key={ann.id} className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm hover:shadow-xl transition-all flex flex-col group">
                  <div className="flex justify-between items-start mb-6">
                    <div className={`w-12 h-12 ${ann.authorId.startsWith('adm') ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'} rounded-2xl flex items-center justify-center text-xl`}>
                      {ann.authorId.startsWith('adm') ? '🛡️' : '📢'}
                    </div>
                    <span className="px-3 py-1 bg-slate-50 text-[10px] font-black text-slate-400 rounded-lg uppercase tracking-widest">
                      {ann.classId === 'all' || !ann.classId ? 'Global' : 'Segmented'}
                    </span>
                  </div>
                  <h4 className="text-xl font-black text-slate-800 leading-tight group-hover:text-blue-600 transition-colors">{ann.title}</h4>
                  <p className="text-sm text-slate-500 mt-4 line-clamp-4 leading-relaxed flex-1">{ann.content}</p>
                  <div className="mt-8 pt-6 border-t border-slate-50 flex justify-between items-center">
                    <div className="flex flex-col">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">Verified By</span>
                      <span className="text-xs font-bold text-slate-800">{ann.authorId.startsWith('adm') ? 'System Admin' : 'Academic Staff'}</span>
                    </div>
                    {canRetract && (
                      <button 
                        onClick={() => handleRetract(ann.id)}
                        className="text-[10px] font-black text-red-400 uppercase hover:text-red-600 transition-colors"
                      >
                        Retract
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnnouncementManager;
