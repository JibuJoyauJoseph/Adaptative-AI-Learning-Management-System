
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const GradingQueue: React.FC = () => {
  const navigate = useNavigate();
  const [selectedSubmission, setSelectedSubmission] = useState<any | null>(null);
  const [score, setScore] = useState(0);

  const pendingEssays = [
    { id: 's1', studentName: 'Adit Irawan', studentRole: 'Jr. UX Designer', quizTitle: 'Modern History Midterm', question: 'Analyze the impact of the Industrial Revolution on urban labor.', answer: 'Suggested actions that users can perform with certain elements in the interface...', points: 10, submittedAt: '2023-10-24T10:00:00Z', accuracy: '85%' },
    { id: 's2', studentName: 'Emma Watson', studentRole: 'Product Designer', quizTitle: 'Intro to Philosophy', question: 'Compare Stoicism with Epicureanism.', answer: 'Stoicism emphasizes virtue as the sole good...', points: 15, submittedAt: '2023-10-24T11:15:00Z', accuracy: '92%' },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
           <div className="flex items-center space-x-3 text-sm font-bold text-slate-400 mb-2">
              <span>Manual Review</span>
              <span>/</span>
              <span className="text-slate-900">Grading Queue</span>
           </div>
           <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Hand Review Desk</h1>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-10">
        <div className="xl:col-span-1 space-y-4">
           <p className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] mb-4">Awaiting Action ({pendingEssays.length})</p>
           {pendingEssays.map(item => (
             <button 
               key={item.id}
               onClick={() => setSelectedSubmission(item)}
               className={`w-full p-6 rounded-[2.5rem] border transition-all text-left group ${selectedSubmission?.id === item.id ? 'bg-indigo-600 border-indigo-600 shadow-xl shadow-indigo-200' : 'bg-white border-slate-100 hover:border-indigo-100'}`}
             >
                <div className="flex items-center space-x-4 mb-4">
                   <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-black text-xs text-slate-500">AI</div>
                   <div>
                      <p className={`text-sm font-black ${selectedSubmission?.id === item.id ? 'text-white' : 'text-slate-800'}`}>{item.studentName}</p>
                      <p className={`text-[10px] font-bold ${selectedSubmission?.id === item.id ? 'text-indigo-100' : 'text-slate-400'} uppercase tracking-tighter`}>{item.studentRole}</p>
                   </div>
                </div>
                <div className="space-y-2">
                   <p className={`text-xs font-bold leading-tight ${selectedSubmission?.id === item.id ? 'text-white' : 'text-slate-600'}`}>{item.quizTitle}</p>
                   <div className="flex justify-between items-center pt-4 border-t border-white/10 mt-4">
                      <span className={`text-[10px] font-black uppercase ${selectedSubmission?.id === item.id ? 'text-indigo-200' : 'text-slate-400'}`}>Score: 0 / {item.points}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${selectedSubmission?.id === item.id ? 'bg-indigo-500 text-white' : 'bg-amber-50 text-amber-600'}`}>Review</span>
                   </div>
                </div>
             </button>
           ))}
        </div>

        <div className="xl:col-span-3">
          {selectedSubmission ? (
            <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden animate-in slide-in-from-bottom-6">
               <div className="bg-indigo-50/30 px-10 py-6 border-b border-slate-50 flex justify-between items-center">
                  <div className="flex items-center space-x-4">
                     <span className="px-4 py-1.5 bg-indigo-600 text-white text-[10px] font-black rounded-full uppercase tracking-widest">Question 10 • Open Ended</span>
                     <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Avg Time: 52s</span>
                  </div>
                  <div className="flex items-center space-x-2">
                     <button className="p-2 hover:bg-white rounded-xl transition-all opacity-40 hover:opacity-100">📁</button>
                     <button className="p-2 hover:bg-white rounded-xl transition-all opacity-40 hover:opacity-100">📋</button>
                  </div>
               </div>

               <div className="p-10 lg:p-14 space-y-12">
                  <div className="space-y-6">
                     <p className="text-2xl font-black text-slate-800 leading-tight">In the context of UI/UX, what does the term "affordance" refer to?</p>
                     <div className="p-8 rounded-[2rem] bg-slate-50 border-2 border-slate-50">
                        <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-4">Adit's Response</p>
                        <p className="text-xl font-bold text-slate-700 italic leading-relaxed">"{selectedSubmission.answer}"</p>
                     </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12 pt-10 border-t border-slate-100">
                     <div className="space-y-8">
                        <div>
                           <div className="flex justify-between items-center mb-6">
                              <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Point Awarded</label>
                              <span className="text-2xl font-black text-indigo-600">{score} <span className="text-slate-300 font-bold">/ {selectedSubmission.points}</span></span>
                           </div>
                           <input 
                              type="range" 
                              min="0" 
                              max={selectedSubmission.points} 
                              value={score} 
                              onChange={(e) => setScore(parseInt(e.target.value))}
                              className="w-full h-2 bg-slate-100 rounded-full appearance-none cursor-pointer accent-indigo-600"
                           />
                           <div className="flex justify-between mt-4 text-[10px] font-black text-slate-300 uppercase tracking-widest">
                              <span>Poor</span>
                              <span>Average</span>
                              <span>Perfect</span>
                           </div>
                        </div>

                        <div className="flex gap-4">
                           <button onClick={() => setScore(0)} className="flex-1 py-4 border-2 border-slate-100 rounded-2xl font-black text-[10px] uppercase text-slate-400 hover:border-red-100 hover:text-red-500 transition-all">❌ Wrong</button>
                           <button onClick={() => setScore(selectedSubmission.points)} className="flex-1 py-4 border-2 border-slate-100 rounded-2xl font-black text-[10px] uppercase text-slate-400 hover:border-emerald-100 hover:text-emerald-500 transition-all">✅ Correct</button>
                        </div>
                     </div>

                     <div>
                        <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-4 block">Feedback Note</label>
                        <textarea className="w-full h-44 bg-slate-50 border-none rounded-[2rem] p-8 text-sm font-medium focus:ring-2 focus:ring-indigo-100 outline-none resize-none" placeholder="Provide constructive feedback for Adit..." />
                     </div>
                  </div>
               </div>

               <div className="p-10 bg-slate-50/50 flex flex-col sm:flex-row justify-between items-center gap-6">
                  <div className="flex items-center space-x-4">
                     <div className="w-10 h-10 rounded-xl bg-white border border-slate-100 flex items-center justify-center font-black text-xs text-slate-300">?</div>
                     <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Manual score required for accuracy metric</p>
                  </div>
                  <div className="flex gap-4 w-full sm:w-auto">
                     <button onClick={() => setSelectedSubmission(null)} className="flex-1 sm:flex-none px-10 py-5 bg-white border border-slate-200 rounded-2xl font-black text-xs uppercase tracking-widest text-slate-500 hover:bg-slate-50 transition-all">Save Draft</button>
                     <button onClick={() => setSelectedSubmission(null)} className="flex-1 sm:flex-none px-16 py-5 bg-indigo-600 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all">Submit Review</button>
                  </div>
               </div>
            </div>
          ) : (
            <div className="h-full min-h-[600px] bg-white rounded-[3rem] border-4 border-dashed border-slate-100 flex flex-col items-center justify-center p-20 text-center animate-in fade-in zoom-in-95">
               <div className="w-32 h-32 bg-indigo-50 rounded-full flex items-center justify-center text-5xl mb-8 grayscale opacity-40">🔎</div>
               <h3 className="text-xl font-black text-slate-300 uppercase tracking-widest">Evaluation Desk Clear</h3>
               <p className="text-slate-400 font-medium max-w-sm mt-4 leading-relaxed">Select a candidate from the left panel to begin manual review of open-ended responses.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GradingQueue;
