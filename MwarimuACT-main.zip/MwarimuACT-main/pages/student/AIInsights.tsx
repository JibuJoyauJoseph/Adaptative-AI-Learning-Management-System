
import React, { useState } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, AreaChart, Area 
} from 'recharts';

const MOCK_HISTORY = [
  { name: 'Quiz 1', score: 45, average: 50 },
  { name: 'Quiz 2', score: 52, average: 51 },
  { name: 'Quiz 3', score: 38, average: 53 },
  { name: 'Quiz 4', score: 65, average: 52 },
  { name: 'Quiz 5', score: 72, average: 54 },
  { name: 'Quiz 6', score: 85, average: 55 },
];

const AIInsights: React.FC = () => {
  const [openNote, setOpenNote] = useState<string | null>('logic');

  const status = {
    label: 'At Risk',
    color: 'text-amber-600',
    bg: 'bg-amber-50',
    border: 'border-amber-100',
    confidence: 68
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      {/* 1. Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tight">AI Learning Assistant</h1>
          <p className="text-slate-500 font-medium">Personalized insights powered by EduQuest AI Core</p>
        </div>
        <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-2xl border border-slate-100 shadow-sm">
          <span className="text-lg">🤖</span>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">v4.2 Analysis Engine</span>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Main Content (Left/Middle) */}
        <div className="xl:col-span-2 space-y-8">
          
          {/* 3. AI Insight Panel */}
          <div className="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 text-6xl opacity-10 group-hover:scale-110 transition-transform">🧠</div>
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest mb-6">AI Insight Summary</h3>
            <p className="text-xl font-bold text-slate-700 leading-relaxed mb-8 max-w-2xl">
              "Alex, you are showing significant improvement in <span className="text-indigo-600">UI Layouts</span>, but your recent scores suggest you struggle with <span className="text-amber-600">Accessibility Standards</span>. Focus on the 'WCAG 2.1' module this week."
            </p>
            <div className="flex flex-wrap gap-3">
               <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Strengths</span>
                  <div className="flex gap-2">
                    {['Layouts', 'Grid Systems', 'Typography'].map(t => (
                      <span key={t} className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase">{t}</span>
                    ))}
                  </div>
               </div>
               <div className="w-px h-10 bg-slate-100 mx-2 self-end"></div>
               <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Weak Areas</span>
                  <div className="flex gap-2">
                    {['Accessibility', 'Color Contrast'].map(t => (
                      <span key={t} className="px-3 py-1 bg-amber-50 text-amber-600 rounded-full text-[10px] font-black uppercase">{t}</span>
                    ))}
                  </div>
               </div>
            </div>
          </div>

          {/* 4. Quiz Feedback Section */}
          <div className="space-y-6">
            <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest px-2">Detailed Quiz Feedback</h3>
            <div className="grid gap-4">
              {[
                { title: 'Intro to Design Systems', score: '85/100', status: 'Passed', time: '12m / 30m', insight: 'Excellent time management. Your logic in multi-select questions was 100% accurate.' },
                { title: 'Visual Hierarchy Exam', score: '42/100', status: 'Failed', time: '28m / 30m', insight: 'Negative marking reduced your score by 12pts. Avoid guessing when unsure of the answer.' },
              ].map((q, i) => (
                <div key={i} className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm hover:shadow-md transition-shadow flex flex-col md:flex-row gap-6">
                  <div className="md:w-48 shrink-0">
                    <p className="text-sm font-black text-slate-800 mb-2">{q.title}</p>
                    <div className="flex items-center space-x-2">
                       <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase ${q.status === 'Passed' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>{q.status}</span>
                       <span className="text-[10px] font-bold text-slate-400">{q.score}</span>
                    </div>
                  </div>
                  <div className="flex-1 bg-slate-50/50 rounded-2xl p-4 border border-slate-100/50">
                    <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">AI Context</p>
                    <p className="text-xs font-medium text-slate-600 leading-relaxed">{q.insight}</p>
                  </div>
                  <div className="text-right flex flex-col justify-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">Completion Time</p>
                    <p className="text-xs font-bold text-slate-800">{q.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 6. AI Notes Section */}
          <div className="space-y-4">
             <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest px-2">Smart Study Notes</h3>
             <div className="space-y-3">
                {[
                  { id: 'logic', title: 'Logic Gates & Boolean Algebra', content: 'AI Summary: Focus on De Morgans laws. Your last error was inverting an AND gate result prematurely. Practice NAND/NOR conversions.' },
                  { id: 'ux', title: 'UX Laws: Fitt\'s Law', content: 'AI Summary: Distance and size determine targeting speed. You missed the question about touch targets on mobile—remember the 44px rule.' },
                ].map(note => (
                  <div key={note.id} className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
                    <button 
                      onClick={() => setOpenNote(openNote === note.id ? null : note.id)}
                      className="w-full px-6 py-4 flex justify-between items-center hover:bg-slate-50 transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-indigo-600 text-xs font-black uppercase tracking-widest">Suggested by AI</span>
                        <span className="text-sm font-black text-slate-800">{note.title}</span>
                      </div>
                      <span className="text-slate-300">{openNote === note.id ? '−' : '+'}</span>
                    </button>
                    {openNote === note.id && (
                      <div className="px-6 pb-6 pt-2 animate-in slide-in-from-top-2">
                        <div className="p-4 bg-indigo-50/30 rounded-xl text-xs font-medium text-slate-600 leading-relaxed border-l-4 border-indigo-600">
                          {note.content}
                        </div>
                        <div className="mt-4 flex gap-2">
                           <button className="text-[9px] font-black text-indigo-600 uppercase border border-indigo-100 px-3 py-1.5 rounded-lg hover:bg-indigo-50">Add to Favorites</button>
                           <button className="text-[9px] font-black text-slate-400 uppercase border border-slate-100 px-3 py-1.5 rounded-lg hover:bg-slate-50">Edit Context</button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
             </div>
          </div>
        </div>

        {/* Sidebar (Right) */}
        <div className="space-y-8">
          
          {/* 2. User Status Card */}
          <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm text-center">
            <div className="w-20 h-20 rounded-full bg-slate-100 mx-auto mb-6 flex items-center justify-center border-4 border-white shadow-lg">
               <span className="text-2xl font-black text-slate-400">AJ</span>
            </div>
            <h2 className="text-xl font-black text-slate-900">Alex Johnson</h2>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-6">Interaction Design • Year 2</p>
            
            <div className={`py-2 px-4 rounded-xl ${status.bg} ${status.border} inline-block mb-8`}>
               <span className={`text-[10px] font-black uppercase tracking-widest ${status.color}`}>Status: {status.label}</span>
            </div>

            <div className="space-y-3">
               <div className="flex justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  <span>Confidence Level</span>
                  <span className="text-indigo-600">{status.confidence}%</span>
               </div>
               <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-600 rounded-full" style={{ width: `${status.confidence}%` }}></div>
               </div>
               <p className="text-[9px] text-slate-400 italic">Target: 85% to reach "Proficient"</p>
            </div>
          </div>

          {/* 5. Recommendations Panel */}
          <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest mb-6 flex items-center">
              <span className="mr-2">🎯</span> Recommendations
            </h3>
            <div className="space-y-4">
              {[
                { type: 'lesson', label: 'Revise Color Contrast Modules', icon: '📘' },
                { type: 'practice', label: 'Take WCAG Practice Quiz', icon: '🧠' },
                { type: 'video', label: 'Watch "Designing for Dyslexia"', icon: '🎥' },
                { type: 'review', label: 'Schedule Review with Prof. Miller', icon: '📝' },
              ].map((item, i) => (
                <div key={i} className="flex items-center group cursor-pointer">
                  <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-xs group-hover:bg-indigo-50 transition-colors mr-3">
                    {item.icon}
                  </div>
                  <span className="text-xs font-bold text-slate-600 group-hover:text-indigo-600 transition-colors">{item.label}</span>
                  <input type="checkbox" className="ml-auto w-4 h-4 rounded-md border-slate-200 text-indigo-600 focus:ring-indigo-50" />
                </div>
              ))}
            </div>
          </div>

          {/* 7. History & Progress Chart */}
          <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest mb-6">Learning Velocity</h3>
            <div className="h-48 w-full">
               <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={MOCK_HISTORY}>
                    <defs>
                      <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" hide />
                    <YAxis hide domain={[0, 100]} />
                    <Tooltip 
                      contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', fontSize: '10px', fontWeight: 'bold' }} 
                      labelStyle={{ display: 'none' }}
                    />
                    <Area type="monotone" dataKey="score" stroke="#4f46e5" strokeWidth={3} fillOpacity={1} fill="url(#colorScore)" />
                    <Area type="monotone" dataKey="average" stroke="#cbd5e1" strokeWidth={2} strokeDasharray="5 5" fill="transparent" />
                  </AreaChart>
               </ResponsiveContainer>
            </div>
            <div className="mt-4 flex justify-between items-center">
               <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-indigo-600"></div>
                  <span className="text-[9px] font-black text-slate-400 uppercase">Your Performance</span>
               </div>
               <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-slate-300"></div>
                  <span className="text-[9px] font-black text-slate-400 uppercase">Class Average</span>
               </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default AIInsights;
