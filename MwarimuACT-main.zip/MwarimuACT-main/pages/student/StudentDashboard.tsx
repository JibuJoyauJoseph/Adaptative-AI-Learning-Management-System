
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import apiClient from '../../api/client';
import { Quiz } from '../../types';

const StudentDashboard: React.FC = () => {
  const [activeQuizzes, setActiveQuizzes] = useState<Quiz[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchQuizzes = async () => {
      try {
        const { data } = await apiClient.get('/student/quizzes');
        setActiveQuizzes(data);
      } catch (err) {
        console.error('Failed to load quizzes');
      } finally {
        setIsLoading(false);
      }
    };
    fetchQuizzes();
  }, []);

  const StatusPill = ({ status }: { status: string }) => {
    switch (status) {
      case 'LIVE': return <span className="flex items-center space-x-1.5 px-3 py-1 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-full text-[10px] font-black uppercase tracking-widest"><span className="w-1.5 h-1.5 rounded-full bg-indigo-600 animate-pulse"></span><span>Live</span></span>;
      case 'COMPLETED': return <span className="flex items-center space-x-1.5 px-3 py-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-full text-[10px] font-black uppercase tracking-widest"><span>✓</span><span>Completed</span></span>;
      default: return <span className="flex items-center space-x-1.5 px-3 py-1 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 rounded-full text-[10px] font-black uppercase tracking-widest"><span>⟳</span><span>In Progress</span></span>;
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
           <div className="flex items-center space-x-3 text-sm font-bold text-slate-400 dark:text-slate-500 mb-2">
              <span>Reports</span>
              <span>/</span>
              <span className="text-slate-900 dark:text-slate-100">Quiz Overview</span>
           </div>
           <h1 className="text-4xl font-black text-slate-900 dark:text-slate-100 uppercase tracking-tight">Your Progress</h1>
        </div>
        <div className="flex items-center space-x-4">
           <button className="px-6 py-3 bg-indigo-600 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-indigo-700 shadow-xl shadow-indigo-100 dark:shadow-none transition-all">Download Report</button>
           <button className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-all">🔍</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         {[
           { label: 'Overall Accuracy', value: '0%', trend: 'Pending Data', color: 'text-indigo-600 dark:text-indigo-400' },
           { label: 'Courses Active', value: '0', trend: 'Updating...', color: 'text-emerald-600 dark:text-emerald-400' },
           { label: 'Pending Reviews', value: '0', trend: 'No pending', color: 'text-amber-600 dark:text-amber-400' },
         ].map((stat, i) => (
           <div key={i} className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col items-center text-center">
              <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-4">{stat.label}</span>
              <p className={`text-4xl font-black ${stat.color} mb-2`}>{stat.value}</p>
              <span className="text-[10px] font-black text-slate-300 dark:text-slate-600 uppercase">{stat.trend}</span>
           </div>
         ))}
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden min-h-[400px]">
        <div className="p-8 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center">
           <h3 className="font-black text-slate-800 dark:text-slate-100 text-sm uppercase tracking-widest">Assigned Assessments</h3>
           <button className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase hover:underline">Refresh List</button>
        </div>

        {isLoading ? (
          <div className="p-20 text-center animate-pulse">
            <p className="text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">Synchronizing assessments...</p>
          </div>
        ) : activeQuizzes.length === 0 ? (
          <div className="p-20 text-center">
             <div className="text-5xl mb-6">📝</div>
             <p className="text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">No active quizzes assigned to your profile</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left min-w-[900px]">
              <thead className="bg-slate-50/50 dark:bg-slate-800/50 text-[10px] font-black uppercase text-slate-400 dark:text-slate-500 tracking-widest border-b border-slate-50 dark:border-slate-800">
                <tr>
                  <th className="px-8 py-6">Quiz Name</th>
                  <th className="px-8 py-6">Status</th>
                  <th className="px-8 py-6">Weight</th>
                  <th className="px-8 py-6">Assigned By</th>
                  <th className="px-8 py-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                {activeQuizzes.map((quiz) => (
                  <tr key={quiz.id} className="hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors group">
                    <td className="px-8 py-6">
                      <div>
                        <p className="text-sm font-black text-slate-800 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{quiz.title}</p>
                        <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mt-1 tracking-tight">{quiz.description}</p>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <StatusPill status={quiz.status || 'LIVE'} />
                    </td>
                    <td className="px-8 py-6">
                      <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase">Weight: 1.0</span>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center space-x-2">
                         <div className="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-[8px] font-black">AI</div>
                         <span className="text-xs font-bold text-slate-600 dark:text-slate-400">System Admin</span>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                       <Link 
                        to={`/quiz/${quiz.id}`}
                        className="px-6 py-2 bg-slate-900 dark:bg-slate-800 text-white dark:text-slate-100 text-[10px] font-black uppercase rounded-xl hover:bg-indigo-600 dark:hover:bg-indigo-700 transition-all shadow-lg"
                       >
                         Enter Session
                       </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentDashboard;
