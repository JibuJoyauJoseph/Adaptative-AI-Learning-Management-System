
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import apiClient from '../../api/client';
import { Quiz, Answer, QuestionType } from '../../types';

const MOCK_QUIZ: Quiz = {
  id: 'q1',
  title: 'Advanced Calculus',
  description: 'Midterm Evaluation - Fall Semester',
  durationMinutes: 45,
  passMark: 50,
  negativeMarking: 0.25,
  creatorId: 't1',
  classId: 'c1',
  createdAt: new Date().toISOString(),
  questions: [
    { id: 'ques-1', text: 'Determine the derivative of f(x) = sin(x) + e^(2x).', type: QuestionType.MCQ, points: 5, options: ['cos(x) + 2e^(2x)', 'cos(x) + e^(2x)', '-cos(x) + 2e^(2x)', 'sin(x) + 2e^(2x)'], correctAnswer: 'cos(x) + 2e^(2x)' },
    { id: 'ques-2', text: 'Does the function f(x) = 1/x have a defined limit at x = 0?', type: QuestionType.TRUE_FALSE, points: 2, correctAnswer: 'False' },
    { id: 'ques-3', text: 'Elaborate on the practical applications of integration in structural engineering.', type: QuestionType.ESSAY, points: 10 }
  ]
};

const QuizSession: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentIdx, setCurrentIdx] = useState(0);

  const submitQuiz = useCallback(async () => {
    if (isSubmitting || !quiz) return;
    setIsSubmitting(true);
    // Simulation
    await new Promise(resolve => setTimeout(resolve, 2000));
    navigate('/dashboard');
  }, [quiz, isSubmitting, navigate]);

  useEffect(() => {
    // Demo Fetch
    setQuiz(MOCK_QUIZ);
    setTimeLeft(MOCK_QUIZ.durationMinutes * 60);
  }, [id]);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
      return () => clearInterval(timer);
    } else if (quiz && timeLeft === 0) {
      submitQuiz();
    }
  }, [timeLeft, quiz, submitQuiz]);

  if (!quiz) return null;

  const currentQuestion = quiz.questions[currentIdx];
  const progress = ((currentIdx + 1) / quiz.questions.length) * 100;
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in slide-in-from-bottom-6 duration-500 pb-20">
      {/* Top Exam Bar */}
      <div className="bg-white/80 backdrop-blur-xl border border-slate-100 rounded-[2rem] p-6 lg:p-8 flex flex-col md:flex-row justify-between items-center gap-6 sticky top-4 z-40 shadow-xl shadow-slate-200/50">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-white font-black">EX</div>
          <div>
            <h1 className="text-xl font-black text-slate-800 leading-none">{quiz.title}</h1>
            <p className="text-[10px] font-black uppercase text-slate-400 mt-2 tracking-widest">Candidate: Alex Johnson • ID: 8234-X</p>
          </div>
        </div>

        <div className="flex items-center space-x-8">
           <div className="flex flex-col items-end">
              <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">Time Remaining</span>
              <div className={`text-2xl font-mono font-black ${timeLeft < 300 ? 'text-red-500 animate-pulse' : 'text-blue-600'}`}>
                {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
              </div>
           </div>
           <div className="h-10 w-px bg-slate-100 hidden md:block"></div>
           <div className="flex items-center space-x-3 bg-green-50 px-4 py-2 rounded-2xl border border-green-100">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
              </span>
              <span className="text-[10px] font-black text-green-700 uppercase tracking-widest">Active Session</span>
           </div>
        </div>
      </div>

      {/* Progress Path */}
      <div className="px-4">
        <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
          <div className="h-full bg-blue-600 transition-all duration-500 ease-out" style={{ width: `${progress}%` }}></div>
        </div>
        <div className="flex justify-between mt-3 px-1 text-[10px] font-black text-slate-400 uppercase tracking-widest">
           <span>Progress: {Math.round(progress)}%</span>
           <span>Question {currentIdx + 1} of {quiz.questions.length}</span>
        </div>
      </div>

      {/* Question Canvas */}
      <div className="bg-white rounded-[3rem] border border-slate-100 shadow-2xl shadow-slate-200/50 overflow-hidden">
        <div className="p-8 lg:p-16 space-y-12">
          <div className="space-y-6">
            <span className="inline-block px-4 py-1 bg-blue-50 text-blue-600 text-[10px] font-black uppercase tracking-[0.2em] rounded-full">
              {currentQuestion.type.replace('_', ' ')} • {currentQuestion.points} pts
            </span>
            <h2 className="text-2xl lg:text-4xl font-black text-slate-900 leading-tight">
              {currentQuestion.text}
            </h2>
          </div>

          <div className="grid gap-4">
            {currentQuestion.type === QuestionType.MCQ && currentQuestion.options?.map((option, i) => (
              <button 
                key={i}
                onClick={() => setAnswers({...answers, [currentQuestion.id]: option})}
                className={`w-full text-left p-6 lg:p-8 rounded-[2rem] border-2 transition-all flex items-center justify-between group ${
                  answers[currentQuestion.id] === option 
                    ? 'bg-blue-600 border-blue-600 text-white shadow-xl shadow-blue-600/20' 
                    : 'bg-white border-slate-100 hover:border-blue-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span className="text-lg lg:text-xl font-bold">{option}</span>
                <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center shrink-0 ${
                  answers[currentQuestion.id] === option ? 'border-white' : 'border-slate-200'
                }`}>
                  {answers[currentQuestion.id] === option && <div className="w-3 h-3 bg-white rounded-full"></div>}
                </div>
              </button>
            ))}

            {currentQuestion.type === QuestionType.TRUE_FALSE && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                 {['True', 'False'].map(val => (
                   <button 
                    key={val}
                    onClick={() => setAnswers({...answers, [currentQuestion.id]: val})}
                    className={`p-10 lg:p-16 rounded-[2.5rem] border-2 transition-all flex flex-col items-center space-y-4 ${
                      answers[currentQuestion.id] === val 
                        ? 'bg-blue-600 border-blue-600 text-white' 
                        : 'bg-white border-slate-100 hover:border-blue-100'
                    }`}
                   >
                     <span className="text-4xl">{val === 'True' ? '✅' : '❌'}</span>
                     <span className="text-2xl font-black">{val}</span>
                   </button>
                 ))}
              </div>
            )}

            {currentQuestion.type === QuestionType.ESSAY && (
              <textarea 
                className="w-full h-80 p-10 rounded-[2.5rem] border-2 border-slate-100 bg-slate-50 focus:bg-white focus:border-blue-600 outline-none text-xl leading-relaxed text-slate-800 transition-all shadow-inner"
                placeholder="Compose your comprehensive response here..."
                value={answers[currentQuestion.id] || ''}
                onChange={(e) => setAnswers({...answers, [currentQuestion.id]: e.target.value})}
              />
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="p-8 lg:p-12 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-6">
          <button 
            disabled={currentIdx === 0}
            onClick={() => setCurrentIdx(i => i - 1)}
            className="w-full sm:w-auto px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest text-slate-500 bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 transition-all"
          >
            ← Previous
          </button>
          
          <div className="flex items-center space-x-4 w-full sm:w-auto">
             <div className="hidden lg:block text-right mr-4">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Penalty Risk</p>
                <p className="text-xs font-bold text-red-400">-{quiz.negativeMarking} per wrong MCQ</p>
             </div>
             {currentIdx === quiz.questions.length - 1 ? (
               <button 
                onClick={submitQuiz}
                disabled={isSubmitting}
                className="w-full sm:w-auto px-16 py-5 bg-green-600 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-green-700 shadow-2xl shadow-green-600/20 transition-all disabled:opacity-50"
               >
                 {isSubmitting ? 'Processing...' : 'Complete Exam'}
               </button>
             ) : (
               <button 
                onClick={() => setCurrentIdx(i => i + 1)}
                className="w-full sm:w-auto px-16 py-5 bg-slate-900 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-blue-600 shadow-2xl shadow-slate-900/10 transition-all"
               >
                 Next Question →
               </button>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuizSession;
