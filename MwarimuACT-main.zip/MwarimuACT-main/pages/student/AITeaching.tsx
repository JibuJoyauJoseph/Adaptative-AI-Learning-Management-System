
import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';

const MOCK_NOTE_TEXT = "In thermodynamics, the Second Law states that the total entropy of an isolated system can never decrease over time. It can remain constant in ideal cases where the system is in a steady state or undergoing a reversible process. This essentially means that energy quality tends to degrade, and disorder naturally increases within a closed environment. This concept is crucial for understanding engine efficiency and the arrow of time.";

const AITeaching: React.FC = () => {
  const { user } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isMicActive, setIsMicActive] = useState(false);
  const [currentProblem, setCurrentProblem] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isAiThinking, setIsAiThinking] = useState(false);
  
  // Teaching Screen States
  const [isTeaching, setIsTeaching] = useState(false);
  const [highlightedWordIndex, setHighlightedWordIndex] = useState(-1);
  const [teachingText, setTeachingText] = useState(MOCK_NOTE_TEXT);

  const words = teachingText.split(' ');
  const progressPercent = words.length > 0 ? ((highlightedWordIndex + 1) / words.length) * 100 : 0;

  const toggleCamera = async () => {
    if (isCameraActive) {
      const stream = videoRef.current?.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
      if (videoRef.current) videoRef.current.srcObject = null;
      setIsCameraActive(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: isMicActive });
        if (videoRef.current) videoRef.current.srcObject = stream;
        setIsCameraActive(true);
      } catch (err) {
        alert("Unable to access camera. Please check permissions.");
      }
    }
  };

  const startTeaching = () => {
    setIsTeaching(true);
    if (highlightedWordIndex >= words.length - 1) {
      setHighlightedWordIndex(0);
    } else if (highlightedWordIndex === -1) {
      setHighlightedWordIndex(0);
    }
  };

  const pauseTeaching = () => {
    setIsTeaching(false);
  };

  const seekTo = (index: number) => {
    setHighlightedWordIndex(index);
  };

  useEffect(() => {
    let interval: any;
    if (isTeaching && highlightedWordIndex < words.length) {
      interval = setInterval(() => {
        setHighlightedWordIndex(prev => {
          if (prev >= words.length - 1) {
            setIsTeaching(false);
            return prev;
          }
          return prev + 1;
        });
      }, 400); // Cinematic pace
    }
    return () => clearInterval(interval);
  }, [isTeaching, highlightedWordIndex, words.length]);

  // Auto-scroll the text container to keep highlighted word visible
  useEffect(() => {
    const activeWord = document.getElementById(`word-${highlightedWordIndex}`);
    if (activeWord && scrollContainerRef.current) {
      activeWord.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [highlightedWordIndex]);

  const handleAskProblem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentProblem.trim()) return;

    setIsAiThinking(true);
    setAiResponse(null);
    
    setTimeout(() => {
      setAiResponse(`I've found the relevant theory. I'll now 'lead' you through a breakdown of the Second Law of Thermodynamics.`);
      setTeachingText(MOCK_NOTE_TEXT);
      setIsAiThinking(false);
      setCurrentProblem('');
      seekTo(0);
      startTeaching();
    }, 1500);
  };

  return (
    <div className="h-[calc(100vh-120px)] flex gap-6 animate-in fade-in duration-700">
      {/* Sidebar Controls */}
      <aside className="w-80 flex flex-col bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden shrink-0">
        <div className="p-8 border-b border-slate-50">
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest mb-2">Query Engine</h3>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">AI Interaction Interface</p>
        </div>

        <div className="flex-1 p-6 space-y-8 overflow-y-auto">
          <form onSubmit={handleAskProblem} className="space-y-4">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Ask AI Tutor</label>
            <textarea 
              value={currentProblem}
              onChange={(e) => setCurrentProblem(e.target.value)}
              placeholder="Type your question or show a diagram..."
              className="w-full h-40 p-5 bg-slate-50 border-2 border-slate-50 rounded-[1.5rem] focus:border-indigo-600 focus:bg-white outline-none transition-all font-medium text-sm resize-none shadow-inner"
            />
            <button 
              type="submit"
              disabled={isAiThinking}
              className="w-full py-4 bg-indigo-600 text-white font-black text-[10px] uppercase tracking-widest rounded-xl hover:bg-indigo-700 shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <span>{isAiThinking ? 'Analyzing...' : 'Execute Analysis'}</span>
              <span>⚡</span>
            </button>
          </form>

          <div className="p-6 bg-slate-50 rounded-3xl space-y-4">
             <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Workspace Tools</h4>
             <div className="grid grid-cols-2 gap-3">
                <button onClick={toggleCamera} className={`p-4 rounded-2xl flex flex-col items-center gap-2 border transition-all ${isCameraActive ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-400 border-slate-100'}`}>
                   <span className="text-xl">{isCameraActive ? '📹' : '📵'}</span>
                   <span className="text-[8px] font-black uppercase">Cam PIP</span>
                </button>
                <button onClick={() => setIsMicActive(!isMicActive)} className={`p-4 rounded-2xl flex flex-col items-center gap-2 border transition-all ${isMicActive ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-400 border-slate-100'}`}>
                   <span className="text-xl">{isMicActive ? '🎙️' : '🔇'}</span>
                   <span className="text-[8px] font-black uppercase">Voice</span>
                </button>
             </div>
          </div>
        </div>
      </aside>

      {/* Main Teaching Screen - Video Player Style */}
      <main className="flex-1 flex flex-col gap-6">
        <div className="flex-1 bg-black rounded-[3rem] relative overflow-hidden shadow-2xl flex flex-col group">
          
          {/* Header Overlay */}
          <div className="absolute top-0 inset-x-0 p-8 flex justify-between items-start z-30 bg-gradient-to-b from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
             <div className="flex flex-col">
                <h2 className="text-white font-black text-xs uppercase tracking-widest flex items-center gap-2">
                   <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                   Module: Thermodynamics Core Concepts
                </h2>
                <p className="text-white/40 text-[10px] font-bold uppercase mt-1">Generated by EduQuest AI</p>
             </div>
             <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-xl border border-white/10">
                <span className="text-[10px] font-black text-white uppercase tracking-widest">Quality: 4K HD-AI</span>
             </div>
          </div>

          {/* Cinematic Typography Viewport */}
          <div 
            ref={scrollContainerRef}
            className="flex-1 overflow-y-auto px-12 lg:px-32 py-40 flex items-center justify-center scroll-smooth scrollbar-hide"
          >
             <div className="max-w-5xl">
                {highlightedWordIndex === -1 && !isAiThinking ? (
                  <div className="text-center space-y-8 animate-in zoom-in-95 duration-700">
                    <div className="w-24 h-24 bg-white/5 rounded-full mx-auto flex items-center justify-center text-5xl opacity-40">🎬</div>
                    <div className="space-y-2">
                       <h3 className="text-2xl font-black text-white uppercase tracking-widest">Screen Standby</h3>
                       <p className="text-white/30 font-medium">Input a problem or start a guided module to begin the visual lecture.</p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap justify-center gap-x-3 gap-y-6 leading-tight select-none">
                    {words.map((word, idx) => (
                      <span 
                        key={idx} 
                        id={`word-${idx}`}
                        onClick={() => seekTo(idx)}
                        className={`text-3xl lg:text-6xl font-black transition-all duration-500 cursor-pointer rounded-xl px-2 py-1 ${
                          idx === highlightedWordIndex 
                            ? 'text-indigo-400 scale-125 z-10 brightness-150 drop-shadow-[0_0_20px_rgba(129,140,248,0.5)]' 
                            : idx < highlightedWordIndex 
                              ? 'text-white/80' 
                              : 'text-white/10'
                        }`}
                      >
                        {word}
                      </span>
                    ))}
                  </div>
                )}
             </div>
          </div>

          {/* PIP Camera Overlay */}
          {isCameraActive && (
            <div className="absolute top-24 right-10 w-48 h-32 rounded-3xl border-2 border-white/20 overflow-hidden shadow-2xl z-20 group/pip">
               <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                className="w-full h-full object-cover transform scale-x-[-1] bg-slate-800"
              />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover/pip:opacity-100 transition-opacity flex items-center justify-center">
                 <button onClick={toggleCamera} className="text-white text-[10px] font-black uppercase tracking-widest">Close PIP</button>
              </div>
            </div>
          )}

          {/* Video Player Style Control Bar */}
          <div className="absolute bottom-0 inset-x-0 p-8 pt-20 bg-gradient-to-t from-black/95 via-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity z-40">
             {/* Progress Bar (Seeker) */}
             <div className="group/seeker relative h-1.5 w-full bg-white/10 rounded-full mb-6 cursor-pointer">
                <div 
                  className="absolute h-full bg-indigo-600 rounded-full flex items-center justify-end"
                  style={{ width: `${progressPercent}%` }}
                >
                   <div className="w-4 h-4 bg-white rounded-full shadow-lg scale-0 group-hover/seeker:scale-100 transition-transform"></div>
                </div>
             </div>

             <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                   <button 
                    onClick={isTeaching ? pauseTeaching : startTeaching}
                    className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-black text-xl hover:scale-110 transition-transform shadow-xl"
                   >
                      {isTeaching ? '⏸' : '▶'}
                   </button>
                   <button onClick={() => seekTo(0)} className="text-white/60 hover:text-white transition-colors text-xl">↺</button>
                   <div className="flex items-center space-x-2 text-[10px] font-black text-white/40 uppercase tracking-widest">
                      <span className="text-white">{Math.floor((highlightedWordIndex + 1) / 3)}:{(highlightedWordIndex + 1) % 60}</span>
                      <span>/</span>
                      <span>{Math.floor(words.length / 3)}:{words.length % 60}</span>
                   </div>
                </div>

                <div className="flex items-center space-x-6">
                   <div className="flex items-center space-x-3">
                      <span className="text-xs">🔊</span>
                      <div className="w-20 h-1 bg-white/20 rounded-full overflow-hidden">
                         <div className="w-2/3 h-full bg-white"></div>
                      </div>
                   </div>
                   <button className="text-white/60 hover:text-white transition-colors">⚙️</button>
                   <button className="text-white/60 hover:text-white transition-colors">⛶</button>
                </div>
             </div>
          </div>

          {/* Thinking Overlay */}
          {isAiThinking && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center z-50">
               <div className="relative">
                  <div className="w-24 h-24 border-4 border-white/10 border-t-indigo-500 rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center text-2xl">🤖</div>
               </div>
               <p className="mt-6 text-indigo-400 font-black text-xs uppercase tracking-[0.2em] animate-pulse">Synchronizing Neural Path...</p>
            </div>
          )}
        </div>

        {/* Global Footer Stats */}
        <div className="bg-white px-10 py-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex justify-between items-center">
           <div className="flex items-center space-x-8">
              <div className="flex items-center gap-2">
                 <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                 <span className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Teacher Presence: Verified</span>
              </div>
              <div className="flex items-center gap-2">
                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Confidence: <span className="text-indigo-600">99.8%</span></span>
              </div>
           </div>
           <button className="px-10 py-4 bg-slate-900 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-indigo-600 transition-all shadow-xl shadow-slate-200">
              End Live Session
           </button>
        </div>
      </main>
    </div>
  );
};

export default AITeaching;
