
import React, { useState } from 'react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

const MOCK_RADAR_DATA = [
  { subject: 'UI Layout', A: 120, fullMark: 150 },
  { subject: 'Typography', A: 98, fullMark: 150 },
  { subject: 'Color Theory', A: 86, fullMark: 150 },
  { subject: 'Accessibility', A: 99, fullMark: 150 },
  { subject: 'User Research', A: 85, fullMark: 150 },
  { subject: 'Prototyping', A: 65, fullMark: 150 },
];

const MOCK_PROGRESS_DATA = [
  { name: 'Mon', score: 40 },
  { name: 'Tue', score: 30 },
  { name: 'Wed', score: 65 },
  { name: 'Thu', score: 45 },
  { name: 'Fri', score: 85 },
  { name: 'Sat', score: 70 },
  { name: 'Sun', score: 90 },
];

const AILearningHub: React.FC = () => {
  const [chatMessage, setChatMessage] = useState('');
  const [messages, setMessages] = useState([
    { role: 'ai', text: "Hello Alex! I've analyzed your recent 'Advanced Calculus' quiz. You excelled in derivatives but might need a refresher on Integration by Parts. Would you like to review some targeted notes?" }
  ]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;
    setMessages([...messages, { role: 'user', text: chatMessage }]);
    setChatMessage('');
    // Mock response
    setTimeout(() => {
      setMessages(prev => [...prev, { role: 'ai', text: "I've logged this to your learning path. Generating a summary of Integration by Parts for you now..." }]);
    }, 1000);
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <div className="flex items-center space-x-3 text-sm font-bold text-slate-400 mb-2">
            <span>Learning Path</span>
            <span>/</span>
            <span className="text-slate-900 font-black">AI Architect</span>
          </div>
          <h1 className="text-4xl font-black text-slate-900 uppercase tracking-tight">AI Learning Hub</h1>
        </div>
        <div className="flex items-center space-x-3">
          <span className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-indigo-100">AI Model: Gemini 2.0 Optimized</span>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Left Column: Weakness Analytics */}
        <div className="xl:col-span-1 space-y-8">
          <div className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-sm">
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest mb-8">Skill Proficiency Matrix</h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={MOCK_RADAR_DATA}>
                  <PolarGrid stroke="#f1f5f9" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 900 }} />
                  <Radar name="Student" dataKey="A" stroke="#4f46e5" fill="#4f46e5" fillOpacity={0.15} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-8 p-6 bg-slate-50 rounded-[2rem]">
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">AI Observation</p>
               <p className="text-xs font-bold text-slate-700 leading-relaxed">Your "Prototyping" speed is improving, but logic-branching accuracy in complex flows is a primary bottleneck.</p>
            </div>
          </div>

          <div className="bg-white rounded-[3rem] p-8 border border-slate-100 shadow-sm">
             <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest mb-6">Learning Velocity</h3>
             <div className="h-40 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={MOCK_PROGRESS_DATA}>
                    <XAxis dataKey="name" hide />
                    <YAxis hide />
                    <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} />
                    <Bar dataKey="score" fill="#4f46e5" radius={[10, 10, 10, 10]} barSize={12} />
                  </BarChart>
                </ResponsiveContainer>
             </div>
             <div className="flex justify-between items-center mt-4">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Efficiency</span>
                <span className="text-xl font-black text-indigo-600">+22%</span>
             </div>
          </div>
        </div>

        {/* Right Column: AI Tutor Chat UI */}
        <div className="xl:col-span-2 space-y-8">
          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-xl overflow-hidden flex flex-col h-[700px]">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-indigo-50/20">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white text-xl shadow-lg shadow-indigo-100">🤖</div>
                <div>
                  <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Personal Learning Architect</h3>
                  <div className="flex items-center space-x-2">
                    <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Synchronized with your Curriculum</span>
                  </div>
                </div>
              </div>
              <button className="text-xs font-black text-indigo-600 uppercase hover:underline">Clear History</button>
            </div>

            <div className="flex-1 overflow-y-auto p-8 space-y-6 scroll-smooth">
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
                  <div className={`max-w-[80%] p-6 rounded-[2rem] text-sm leading-relaxed ${
                    m.role === 'user' 
                      ? 'bg-indigo-600 text-white rounded-tr-none shadow-xl shadow-indigo-100 font-bold' 
                      : 'bg-slate-50 text-slate-700 rounded-tl-none border border-slate-100 font-medium'
                  }`}>
                    {m.text}
                  </div>
                </div>
              ))}
            </div>

            <div className="p-8 bg-slate-50/50 border-t border-slate-100">
              <form onSubmit={handleSendMessage} className="relative">
                <input 
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  placeholder="Ask your tutor about a specific concept..." 
                  className="w-full px-8 py-5 rounded-[2rem] bg-white border-2 border-slate-100 focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 outline-none transition-all font-bold text-slate-700 pr-16 shadow-inner"
                />
                <button 
                  type="submit"
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center hover:bg-indigo-700 transition-colors shadow-lg"
                >
                  →
                </button>
              </form>
              <div className="mt-4 flex flex-wrap gap-2 justify-center">
                 {['Summarize my last quiz', 'Explain Integration', 'Practice Questions'].map(hint => (
                   <button 
                    key={hint} 
                    onClick={() => setChatMessage(hint)}
                    className="px-4 py-2 bg-white text-[10px] font-black text-slate-400 uppercase tracking-widest rounded-full border border-slate-100 hover:border-indigo-200 hover:text-indigo-600 transition-all"
                   >
                     {hint}
                   </button>
                 ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
             <div className="bg-indigo-600 rounded-[3rem] p-10 text-white relative overflow-hidden group">
                <h4 className="text-xl font-black mb-4 uppercase tracking-tight">Adaptive Study Plan</h4>
                <p className="text-indigo-100 text-sm font-medium leading-relaxed opacity-80 mb-6">Generated 5 minutes ago based on your accuracy trends.</p>
                <ul className="space-y-3">
                   {['Review Physics Unit 4', 'Take Prototyping Mini-Quiz', 'Watch "Layout Grids" Video'].map((item, i) => (
                     <li key={i} className="flex items-center space-x-3 text-xs font-black uppercase tracking-widest bg-white/10 p-3 rounded-xl border border-white/10 hover:bg-white/20 cursor-pointer transition-all">
                        <span>→</span>
                        <span>{item}</span>
                     </li>
                   ))}
                </ul>
                <div className="absolute top-[-20%] right-[-10%] w-48 h-48 bg-white/5 rounded-full blur-3xl group-hover:scale-125 transition-all duration-1000"></div>
             </div>

             <div className="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-sm flex flex-col justify-center">
                <div className="flex items-center space-x-4 mb-6">
                   <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center text-xl">💡</div>
                   <div>
                      <h5 className="text-sm font-black text-slate-800 uppercase tracking-widest">Focus Point</h5>
                      <p className="text-xs font-bold text-slate-400">Week 4 Learning Goal</p>
                   </div>
                </div>
                <p className="text-sm text-slate-600 font-medium leading-relaxed">
                   "Mastering <strong>Constraint Layouts</strong> will likely boost your design speed by <span className="text-indigo-600 font-black">40%</span>. Start the module today."
                </p>
                <button className="mt-8 w-full py-4 bg-slate-900 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl hover:bg-indigo-600 transition-all shadow-xl shadow-slate-100">Activate Module</button>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AILearningHub;
