
import React, { useState } from 'react';
import { UserRole } from '../../types';

const UserManagement: React.FC = () => {
  const [showModal, setShowModal] = useState(false);
  const [roleFilter, setRoleFilter] = useState<UserRole | 'ALL'>('ALL');

  const mockUsers = [
    { id: '1', name: 'Alice Smith', email: 'alice@edu.com', role: UserRole.STUDENT, status: 'Active' },
    { id: '2', name: 'Dr. Robert', email: 'robert@edu.com', role: UserRole.TEACHER, status: 'Active' },
    { id: '3', name: 'System Admin', email: 'admin@edu.com', role: UserRole.ADMIN, status: 'Active' },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Identity Center</h1>
          <p className="text-slate-500 font-medium">Manage institutional accounts and access privileges.</p>
        </div>
        <button onClick={() => setShowModal(true)} className="px-8 py-4 bg-slate-900 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-blue-600 shadow-2xl transition-all">
          Enroll New User
        </button>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-50 flex flex-wrap gap-4 justify-between items-center">
          <div className="flex gap-2">
            {['ALL', UserRole.STUDENT, UserRole.TEACHER, UserRole.ADMIN].map(role => (
              <button 
                key={role} 
                onClick={() => setRoleFilter(role as any)}
                className={`px-5 py-2 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${roleFilter === role ? 'bg-slate-900 text-white shadow-lg' : 'bg-slate-50 text-slate-400 hover:bg-slate-100'}`}
              >
                {role}
              </button>
            ))}
          </div>
          <div className="relative w-full md:w-64">
            <input placeholder="Filter by name..." className="w-full bg-slate-50 px-4 py-2.5 rounded-xl border border-transparent focus:border-blue-500 outline-none text-sm" />
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 text-[10px] font-black uppercase tracking-widest text-slate-400">
              <tr>
                <th className="px-8 py-5">Full Name & ID</th>
                <th className="px-8 py-5">Institutional Access</th>
                <th className="px-8 py-5">Status</th>
                <th className="px-8 py-5 text-right">Operations</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {mockUsers.filter(u => roleFilter === 'ALL' || u.role === roleFilter).map(u => (
                <tr key={u.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-black text-xs">{u.name.charAt(0)}</div>
                      <div>
                        <p className="text-sm font-black text-slate-800">{u.name}</p>
                        <p className="text-xs text-slate-400 font-medium">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest ${
                      u.role === UserRole.ADMIN ? 'bg-red-50 text-red-600' : 
                      u.role === UserRole.TEACHER ? 'bg-purple-50 text-purple-600' : 'bg-blue-50 text-blue-600'
                    }`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-8 py-6">
                     <div className="flex items-center space-x-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                        <span className="text-[10px] font-bold text-slate-500 uppercase">{u.status}</span>
                     </div>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <button className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-blue-600 transition-colors mr-6">Edit</button>
                    <button className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-red-600 transition-colors">Revoke</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Enroll Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 backdrop-blur-sm bg-slate-900/20 animate-in fade-in duration-300">
           <div className="bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="p-10 space-y-8">
                 <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">New Enrollment</h2>
                    <button onClick={() => setShowModal(false)} className="text-2xl grayscale opacity-30 hover:opacity-100 transition-opacity">✕</button>
                 </div>
                 
                 <div className="space-y-5">
                    <div className="grid grid-cols-2 gap-4">
                       <div>
                          <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2 block">Full Name</label>
                          <input className="w-full bg-slate-50 border-2 border-slate-50 px-4 py-3 rounded-xl focus:border-blue-500 outline-none font-bold" placeholder="E.g. John Doe" />
                       </div>
                       <div>
                          <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2 block">Account Role</label>
                          <select className="w-full bg-slate-50 border-2 border-slate-50 px-4 py-3 rounded-xl focus:border-blue-500 outline-none font-black text-[10px] uppercase tracking-widest">
                             <option value={UserRole.STUDENT}>Student</option>
                             <option value={UserRole.TEACHER}>Teacher</option>
                             <option value={UserRole.ADMIN}>Administrator</option>
                          </select>
                       </div>
                    </div>
                    <div>
                       <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2 block">Institutional Email</label>
                       <input className="w-full bg-slate-50 border-2 border-slate-50 px-4 py-3 rounded-xl focus:border-blue-500 outline-none font-bold" placeholder="user@university.edu" />
                    </div>
                    <div>
                       <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2 block">Initial Password</label>
                       <input type="password" defaultValue="Welcome2024!" className="w-full bg-slate-50 border-2 border-slate-50 px-4 py-3 rounded-xl focus:border-blue-500 outline-none font-bold" />
                    </div>
                 </div>

                 <div className="pt-4 flex flex-col gap-3">
                    <button onClick={() => setShowModal(false)} className="w-full py-4 bg-slate-900 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-blue-600 transition-all shadow-xl">Activate Identity</button>
                    <button onClick={() => setShowModal(false)} className="w-full py-2 font-black text-[10px] text-slate-400 uppercase hover:text-slate-600 transition-all">Cancel Request</button>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
