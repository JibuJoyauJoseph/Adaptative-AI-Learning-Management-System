
import React, { useState } from 'react';

const ClassManagement: React.FC = () => {
  const [showModal, setShowModal] = useState(false);
  const classes = [
    { id: '1', name: 'CS101: Intro to Web', teacher: 'Prof. Xavier', students: 42, color: 'from-blue-500 to-indigo-600' },
    { id: '2', name: 'PH102: Quantum Mechanics', teacher: 'Dr. Manhattan', students: 18, color: 'from-purple-500 to-pink-600' },
    { id: '3', name: 'HS303: Modern History', teacher: 'Emma Watson', students: 35, color: 'from-orange-400 to-red-500' },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Academic Units</h1>
          <p className="text-slate-500 font-medium">Define course structures and assign instructional leads.</p>
        </div>
        <button onClick={() => setShowModal(true)} className="px-8 py-4 bg-slate-900 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-blue-600 shadow-2xl transition-all">
          New Unit
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
         {classes.map(c => (
           <div key={c.id} className="group bg-white rounded-[2.5rem] p-1 border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-slate-200/50 transition-all">
              <div className="p-8 space-y-6">
                 <div className="flex justify-between items-start">
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${c.color} shadow-lg flex items-center justify-center text-white font-black text-xl transition-transform group-hover:scale-110`}>
                      {c.name.substring(0,2)}
                    </div>
                    <button className="p-2 hover:bg-slate-50 rounded-xl transition-colors">⚙️</button>
                 </div>
                 
                 <div>
                    <h3 className="text-xl font-black text-slate-800 leading-tight group-hover:text-blue-600 transition-colors">{c.name}</h3>
                    <p className="text-xs font-bold text-slate-400 mt-2 uppercase tracking-widest flex items-center">
                       <span className="mr-2">👨‍🏫</span> {c.teacher}
                    </p>
                 </div>

                 <div className="pt-6 border-t border-slate-50 flex items-center justify-between">
                    <div className="flex -space-x-2">
                       {[1,2,3,4].map(i => (
                         <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-slate-200 flex items-center justify-center text-[10px] font-black">S{i}</div>
                       ))}
                       <div className="w-8 h-8 rounded-full border-2 border-white bg-blue-50 text-blue-600 flex items-center justify-center text-[8px] font-black">+{c.students - 4}</div>
                    </div>
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{c.students} Active</span>
                 </div>
              </div>
           </div>
         ))}

         <button onClick={() => setShowModal(true)} className="min-h-[250px] border-4 border-dashed border-slate-100 rounded-[2.5rem] flex flex-col items-center justify-center space-y-4 hover:border-blue-100 hover:bg-blue-50/20 transition-all text-slate-300 hover:text-blue-400">
            <span className="text-4xl">+</span>
            <span className="text-xs font-black uppercase tracking-widest">Create Academic Unit</span>
         </button>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 backdrop-blur-sm bg-slate-900/20 animate-in fade-in duration-300">
           <div className="bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="p-10 space-y-8">
                 <div className="flex justify-between items-center">
                    <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">Define Unit</h2>
                    <button onClick={() => setShowModal(false)} className="text-2xl grayscale opacity-30 hover:opacity-100 transition-opacity">✕</button>
                 </div>
                 
                 <div className="space-y-5">
                    <div>
                       <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2 block">Unit Name / Code</label>
                       <input className="w-full bg-slate-50 border-2 border-slate-50 px-4 py-3 rounded-xl focus:border-blue-500 outline-none font-bold" placeholder="E.g. CS101: Introduction to AI" />
                    </div>
                    <div>
                       <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2 block">Assign Instructor</label>
                       <select className="w-full bg-slate-50 border-2 border-slate-50 px-4 py-3 rounded-xl focus:border-blue-500 outline-none font-black text-[10px] uppercase tracking-widest">
                          <option>Dr. Alan Turing</option>
                          <option>Prof. Grace Hopper</option>
                          <option>Dr. Richard Feynman</option>
                       </select>
                    </div>
                    <div>
                       <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2 block">Visual Identifier (Color)</label>
                       <div className="flex gap-3">
                          {['bg-blue-500', 'bg-purple-500', 'bg-orange-500', 'bg-green-500'].map(c => (
                            <button key={c} className={`w-8 h-8 rounded-lg ${c} ring-offset-2 hover:ring-2 ring-slate-200 transition-all`}></button>
                          ))}
                       </div>
                    </div>
                 </div>

                 <div className="pt-4 flex flex-col gap-3">
                    <button onClick={() => setShowModal(false)} className="w-full py-4 bg-slate-900 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-blue-600 transition-all shadow-xl">Deploy Academic Unit</button>
                    <button onClick={() => setShowModal(false)} className="w-full py-2 font-black text-[10px] text-slate-400 uppercase hover:text-slate-600 transition-all">Cancel</button>
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default ClassManagement;
