
import React, { useState, useEffect } from 'react';
import apiClient from '../../api/client';
import { User, Class } from '../../types';

const AdminDashboard: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [classes, setClasses] = useState<Class[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [uRes, cRes] = await Promise.all([
          apiClient.get('/admin/users'),
          apiClient.get('/admin/classes')
        ]);
        setUsers(uRes.data);
        setClasses(cRes.data);
      } catch (err) {
        console.error('Admin data fetch error');
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  if (isLoading) return <div className="p-10 animate-pulse bg-slate-100 rounded-3xl h-64"></div>;

  return (
    <div className="space-y-10">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">System Control Panel</h1>
          <p className="text-slate-500 mt-1">Global management of users, classes, and site configurations.</p>
        </div>
        <div className="flex space-x-3">
          <button className="px-6 py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-all">Export Logs</button>
          <button className="px-6 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-all">Add User</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Total Students', value: 1240, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Total Teachers', value: 58, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: 'Active Classes', value: 34, color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'Quizzes Taken', value: 8432, color: 'text-orange-600', bg: 'bg-orange-50' }
        ].map((stat, i) => (
          <div key={i} className={`p-8 rounded-[2rem] border border-slate-100 bg-white shadow-sm`}>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{stat.label}</span>
            <p className={`text-4xl font-black mt-2 ${stat.color}`}>{stat.value.toLocaleString()}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        <div className="xl:col-span-2 bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50 flex justify-between items-center">
            <h3 className="font-bold text-slate-800">Recent User Registrations</h3>
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search users..." 
                className="pl-4 pr-10 py-2 bg-slate-50 border-none rounded-lg text-sm focus:ring-2 focus:ring-blue-100"
              />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-[10px] uppercase font-bold text-slate-400">
                <tr>
                  <th className="px-6 py-4">User</th>
                  <th className="px-6 py-4">Role</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-xs">{u.name.charAt(0)}</div>
                        <div>
                          <p className="text-sm font-semibold text-slate-800">{u.name}</p>
                          <p className="text-xs text-slate-500">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-md text-[10px] font-black uppercase ${
                        u.role === 'ADMIN' ? 'bg-red-100 text-red-600' : 
                        u.role === 'TEACHER' ? 'bg-purple-100 text-purple-600' : 'bg-blue-100 text-blue-600'
                      }`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-1.5">
                        <div className="w-2 h-2 rounded-full bg-green-500"></div>
                        <span className="text-xs text-slate-600">Active</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <button className="text-slate-400 hover:text-blue-600 mr-4 font-bold text-xs">Edit</button>
                      <button className="text-slate-400 hover:text-red-600 font-bold text-xs">Suspend</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-8">
           <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-8">
              <h3 className="font-bold text-slate-800 mb-6">Class Distribution</h3>
              <div className="space-y-4">
                {classes.map(c => (
                  <div key={c.id} className="p-4 rounded-2xl bg-slate-50 flex justify-between items-center">
                    <div>
                      <p className="font-bold text-slate-800 text-sm">{c.name}</p>
                      <p className="text-[10px] text-slate-400">Instructor ID: {c.teacherId}</p>
                    </div>
                    <span className="px-3 py-1 bg-white border border-slate-100 rounded-lg text-xs font-bold text-slate-600">42 Students</span>
                  </div>
                ))}
              </div>
           </div>

           <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-8 text-white">
              <h3 className="text-xl font-bold mb-4">Server Health</h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold uppercase text-slate-400">
                    <span>CPU Load</span>
                    <span>12%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <div className="w-[12%] h-full bg-blue-500"></div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold uppercase text-slate-400">
                    <span>Memory</span>
                    <span>48%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <div className="w-[48%] h-full bg-purple-500"></div>
                  </div>
                </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
