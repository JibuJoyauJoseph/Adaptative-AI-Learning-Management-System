
import axios from 'axios';

// Assuming backend URL is handled via env or standard proxy
const API_URL = 'http://localhost:5000/api'; 

const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Clear token from storage but don't force a reload. 
      // The application state/context will handle the redirect.
      localStorage.removeItem('token');
    }
    return Promise.reject(error);
  }
);

export default apiClient;
