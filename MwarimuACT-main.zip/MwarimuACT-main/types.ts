
export enum UserRole {
  STUDENT = 'STUDENT',
  TEACHER = 'TEACHER',
  ADMIN = 'ADMIN'
}

export enum QuestionType {
  MCQ = 'MCQ',
  TRUE_FALSE = 'TRUE_FALSE',
  ESSAY = 'ESSAY'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  classId?: string;
}

export interface Quiz {
  id: string;
  title: string;
  description: string;
  durationMinutes: number;
  passMark: number;
  negativeMarking: number;
  creatorId: string;
  classId: string;
  questions: Question[];
  createdAt: string;
  // Added status property to support quiz lifecycle state (e.g., LIVE, COMPLETED, IN_PROGRESS)
  status?: string;
}

export interface Question {
  id: string;
  text: string;
  type: QuestionType;
  points: number;
  options?: string[]; // For MCQ
  correctAnswer?: string; // For MCQ/TF
}

export interface Submission {
  id: string;
  quizId: string;
  studentId: string;
  score: number;
  isPassed: boolean;
  answers: Answer[];
  status: 'SUBMITTED' | 'REVIEWED';
  feedback?: string;
  submittedAt: string;
}

export interface Answer {
  questionId: string;
  content: string;
  isCorrect?: boolean;
  scoreAwarded?: number;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  classId?: string; // Null for global
  authorId: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  isRead: boolean;
  type: 'QUIZ' | 'RESULT' | 'ANNOUNCEMENT';
  createdAt: string;
}

export interface Class {
  id: string;
  name: string;
  teacherId: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}
