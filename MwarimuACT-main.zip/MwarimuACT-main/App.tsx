
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Register from './pages/Register';
import StudentDashboard from './pages/student/StudentDashboard';
import QuizSession from './pages/student/QuizSession';
import AILearningHub from './pages/student/AILearningHub';
import AIInsights from './pages/student/AIInsights';
import AITeaching from './pages/student/AITeaching';
import TeacherDashboard from './pages/teacher/TeacherDashboard';
import CreateQuiz from './pages/teacher/CreateQuiz';
import GradingQueue from './pages/teacher/GradingQueue';
import AnnouncementManager from './pages/teacher/AnnouncementManager';
import AdminDashboard from './pages/admin/AdminDashboard';
import UserManagement from './pages/admin/UserManagement';
import ClassManagement from './pages/admin/ClassManagement';
import { UserRole } from './types';
import { useAuth } from './context/AuthContext';

const RoleRoute: React.FC<{ children: React.ReactElement, allowedRoles: UserRole[] }> = ({ children, allowedRoles }) => {
  const { user, isAuthenticated, isLoading } = useAuth();
  if (isLoading) return null;
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (!user || !allowedRoles.includes(user.role)) return <Navigate to="/unauthorized" replace />;
  return children;
};

const DashboardRedirect: React.FC = () => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  return <Navigate to="/dashboard" />;
};

const RoleDashboard: React.FC = () => {
  const { user } = useAuth();
  if (user?.role === UserRole.STUDENT) return <StudentDashboard />;
  if (user?.role === UserRole.TEACHER) return <TeacherDashboard />;
  if (user?.role === UserRole.ADMIN) return <AdminDashboard />;
  return <Navigate to="/login" />;
};

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            
            <Route path="/" element={<Layout />}>
              <Route index element={<DashboardRedirect />} />
              <Route path="dashboard" element={<RoleDashboard />} />
              
              <Route path="quiz/:id" element={
                <RoleRoute allowedRoles={[UserRole.STUDENT]}>
                  <QuizSession />
                </RoleRoute>
              } />
              
              <Route path="create-quiz" element={
                <RoleRoute allowedRoles={[UserRole.TEACHER, UserRole.ADMIN]}>
                  <CreateQuiz />
                </RoleRoute>
              } />
              <Route path="grading" element={
                <RoleRoute allowedRoles={[UserRole.TEACHER, UserRole.ADMIN]}>
                  <GradingQueue />
                </RoleRoute>
              } />
              <Route path="announcements" element={
                <RoleRoute allowedRoles={[UserRole.TEACHER, UserRole.ADMIN]}>
                  <AnnouncementManager />
                </RoleRoute>
              } />

              <Route path="users" element={
                <RoleRoute allowedRoles={[UserRole.ADMIN]}>
                  <UserManagement />
                </RoleRoute>
              } />
              <Route path="classes" element={
                <RoleRoute allowedRoles={[UserRole.ADMIN]}>
                  <ClassManagement />
                </RoleRoute>
              } />

              <Route path="ai-insights" element={
                 <RoleRoute allowedRoles={[UserRole.STUDENT]}>
                   <AIInsights />
                 </RoleRoute>
              } />
              <Route path="ai-notes" element={
                 <RoleRoute allowedRoles={[UserRole.STUDENT]}>
                   <AILearningHub />
                 </RoleRoute>
              } />
              <Route path="ai-teaching" element={
                 <RoleRoute allowedRoles={[UserRole.STUDENT]}>
                   <AITeaching />
                 </RoleRoute>
              } />
            </Route>

            <Route path="/unauthorized" element={<div className="p-20 text-center font-bold text-3xl">403 - Access Denied</div>} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;
