
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';

const Sidebar: React.FC = () => {
  const { user } = useAuth();
  const location = useLocation();

  const menuItems = {
    [UserRole.STUDENT]: [
      { path: '/dashboard', label: 'Reports', icon: '📊' },
      { path: '/courses', label: 'Course', icon: '📚' },
      { path: '/pages', label: 'Page', icon: '📄' },
      { path: '/assignments', label: 'Assignment', icon: '📎' },
      { path: '/quizzes', label: 'Quiz', icon: '🎯' },
      { path: '/ai-insights', label: 'AI Assistant', icon: '✨' },
      { path: '/ai-notes', label: 'Learning Path', icon: '🧠' },
      { path: '/ai-teaching', label: 'Live Tutor', icon: '🎥' },
    ],
    [UserRole.TEACHER]: [
      { path: '/dashboard', label: 'Reports', icon: '📊' },
      { path: '/grading', label: 'Manual Review', icon: '✍️' },
      { path: '/announcements', label: 'Broadcasts', icon: '📢' },
      { path: '/create-quiz', label: 'Designer', icon: '🛠️' },
    ],
    [UserRole.ADMIN]: [
      { path: '/dashboard', label: 'Overview', icon: '📊' },
      { path: '/users', label: 'Users', icon: '👥' },
      { path: '/classes', label: 'Academic Units', icon: '🏫' },
      { path: '/announcements', label: 'Broadcasts', icon: '📢' },
    ]
  };

  if (!user) return null;

  const activeItems = menuItems[user.role] || [];

  return (
    <>
      <aside className="hidden md:flex flex-col w-20 lg:w-72 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 h-screen fixed left-0 top-0 z-40 transition-all duration-300">
        <div className="p-8 flex items-center">
          <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-200 dark:shadow-none">
             <span className="text-white font-black text-xl">t</span>
          </div>
          <span className="hidden lg:block ml-3 font-black text-xl tracking-tight text-slate-900 dark:text-slate-100 uppercase">EduQuest</span>
        </div>

        <nav className="mt-4 flex-1 px-4 space-y-1">
          <p className="hidden lg:block px-4 mb-4 text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Learning Content</p>
          {activeItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center space-x-0 lg:space-x-4 px-4 py-3.5 rounded-2xl transition-all duration-200 group relative ${
                  isActive 
                    ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400' 
                    : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <span className="text-xl lg:text-lg opacity-80">{item.icon}</span>
                <span className={`hidden lg:block font-bold text-sm tracking-wide ${isActive ? 'text-indigo-700 dark:text-indigo-400' : 'text-slate-600 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-slate-200'}`}>
                  {item.label}
                </span>
                {isActive && <div className="absolute left-0 w-1 h-6 bg-indigo-600 rounded-r-full"></div>}
              </Link>
            );
          })}
        </nav>

        <div className="p-6">
           <div className="bg-indigo-50/50 dark:bg-indigo-900/10 rounded-3xl p-6 border border-indigo-50 dark:border-indigo-900/30 lg:block hidden">
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Get Training AI</p>
              <p className="text-xs text-indigo-900 dark:text-indigo-200 font-bold leading-relaxed mb-4">Unlock advanced learning features now!</p>
              <button className="w-full py-2.5 bg-indigo-600 text-white text-[10px] font-black uppercase rounded-xl hover:bg-indigo-700 transition-all">Try It Now →</button>
           </div>
           
           <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-slate-500 dark:text-slate-400 text-xs shrink-0">RP</div>
              <div className="hidden lg:block truncate">
                 <p className="text-xs font-black text-slate-900 dark:text-slate-100 truncate">{user.name}</p>
                 <p className="text-[10px] text-slate-400 font-bold uppercase">{user.role}</p>
              </div>
           </div>
        </div>
      </aside>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 px-4 py-2 flex justify-around items-center z-50 shadow-2xl transition-colors duration-300">
        {activeItems.slice(0, 5).map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center p-2 rounded-xl ${isActive ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400' : 'text-slate-400'}`}
            >
              <span className="text-xl">{item.icon}</span>
              <span className="text-[9px] font-black uppercase mt-1 tracking-tighter">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </>
  );
};

export default Sidebar;
