
import React, { useState, useEffect } from 'react';
import { Outlet, Navigate, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import apiClient from '../api/client';
import { Notification } from '../types';

const Layout: React.FC = () => {
  const { isAuthenticated, isLoading, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const location = useLocation();

  useEffect(() => {
    if (isAuthenticated) {
      const fetchNotifications = async () => {
        try {
          const { data } = await apiClient.get('/notifications');
          setNotifications(data);
        } catch (e) {
          console.warn('Notification fetch failed');
        }
      };
      fetchNotifications();
    }
  }, [isAuthenticated]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50 dark:bg-slate-950">
        <div className="relative">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-slate-200 dark:border-slate-800 border-t-blue-600"></div>
          <div className="absolute inset-0 flex items-center justify-center text-[10px] font-black text-blue-600">EQ</div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-slate-950 overflow-x-hidden transition-colors duration-300">
      <Sidebar />
      <main className="flex-1 transition-all duration-300 md:ml-20 lg:ml-64 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-20 bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl border-b border-slate-100 dark:border-slate-800 sticky top-0 z-30 flex items-center justify-between px-6 lg:px-10">
          <div className="flex items-center space-x-2">
             <div className="md:hidden w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-black text-white text-xs mr-2">E</div>
             <h2 className="text-sm lg:text-base font-bold text-slate-800 dark:text-slate-100 capitalize">
               {location.pathname.split('/').pop()?.replace('-', ' ') || 'Overview'}
             </h2>
          </div>
          
          <div className="flex items-center space-x-4 lg:space-x-6">
            {/* Theme Toggle */}
            <button 
              onClick={toggleTheme}
              className="w-10 h-10 flex items-center justify-center bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-2xl transition-all shadow-sm"
              title="Toggle Eye-Caring Mode"
            >
              <span className="text-lg">{theme === 'light' ? '🌙' : '☀️'}</span>
            </button>

            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="w-10 h-10 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 rounded-2xl relative transition-colors"
              >
                <span className="text-xl">🔔</span>
                {unreadCount > 0 && (
                  <span className="absolute top-2 right-2 h-2.5 w-2.5 bg-red-500 ring-2 ring-white dark:ring-slate-900 rounded-full"></span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-4 w-72 lg:w-96 bg-white dark:bg-slate-900 rounded-[2rem] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] border border-slate-100 dark:border-slate-800 overflow-hidden z-50 animate-in fade-in slide-in-from-top-4">
                  <div className="p-6 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
                    <h3 className="font-black text-slate-800 dark:text-slate-100 text-sm uppercase tracking-widest">Notifications</h3>
                    <button className="text-[10px] font-black text-blue-600 uppercase hover:text-blue-700">Clear All</button>
                  </div>
                  <div className="max-h-[70vh] overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-12 text-center space-y-3">
                         <div className="text-4xl">🏜️</div>
                         <p className="text-sm font-bold text-slate-400 italic">Nothing new right now</p>
                      </div>
                    ) : (
                      notifications.map(n => (
                        <div key={n.id} className={`p-5 border-b border-slate-50 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer transition-colors ${!n.isRead ? 'bg-blue-50/20 dark:bg-blue-900/10' : ''}`}>
                          <p className="text-xs font-black text-slate-800 dark:text-slate-100 uppercase tracking-tight">{n.title}</p>
                          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            <button 
              onClick={logout}
              className="text-xs font-black uppercase tracking-widest text-red-600 hover:text-white hover:bg-red-600 px-5 py-3 rounded-2xl transition-all border border-red-100 dark:border-red-900/30 shadow-sm"
            >
              Sign Out
            </button>
          </div>
        </header>

        <div className="p-4 lg:p-10 pb-32 md:pb-10 max-w-[1600px] mx-auto w-full">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default Layout;
